package db

import (
	"database/sql"
	_ "embed"
	"encoding/json"
	"fmt"
	"log"
	"strconv"
	"strings"
)

//go:embed tableStructs/RawData/Data/feats&boons.json
var featsBoons []byte

//go:embed tableStructs/RawData/Data/fighting Styles and EldritchInvocations.json
var fightingStylesInvocations []byte

type optionCard struct {
	Title    string   `json:"title"`
	Contents []string `json:"contents"`
	Tags     []string `json:"tags"`
}

// fightingStyleNames is the complete set of fighting style names extracted
// from the class JSON files via the Fighting Style feature refOptionalfeature refs.
var fightingStyleNames = map[string]bool{
	"Archery": true, "Blessed Warrior": true, "Blind Fighting": true,
	"Defense": true, "Druidic Warrior": true, "Dueling": true,
	"Great Weapon Fighting": true, "Interception": true, "Protection": true,
	"Superior Technique": true, "Thrown Weapon Fighting": true,
	"Two-Weapon Fighting": true, "Unarmed Fighting": true,
}

// SeedFeats seeds feats, boons, fighting styles, and eldritch invocations.
// Version rule: PHB'24 preferred over PHB'14 for the same title.
func SeedFeats() {
	seedFeatsBoons()
	seedFightingStylesAndInvocations()
}

func seedFeatsBoons() {
	var cards []optionCard
	if err := json.Unmarshal(featsBoons, &cards); err != nil {
		log.Printf("SeedFeats: parse feats_boons: %v", err)
		return
	}

	phb24 := make(map[string]bool)
	for _, c := range cards {
		if hasTag(c.Tags, "PHB'24") {
			phb24[c.Title] = true
		}
	}

	tx, err := DB.Begin()
	if err != nil {
		log.Printf("SeedFeats: begin tx: %v", err)
		return
	}
	defer tx.Rollback()

	featCount, boonCount := 0, 0

	for _, card := range cards {
		if hasTag(card.Tags, "PHB'14") && phb24[card.Title] {
			continue
		}

		source := getSource(card.Tags)
		isBoon := hasTag(card.Tags, "boon")
		prereq, desc := parseFeatContent(card.Contents)

		if isBoon {
			res, err := tx.Exec(
				`INSERT OR IGNORE INTO boons (name, description, source) VALUES (?,?,?)`,
				card.Title, truncate(desc, 2000), source,
			)
			if err != nil {
				log.Printf("SeedFeats: insert boon %q: %v", card.Title, err)
				continue
			}
			id, _ := res.LastInsertId()
			if id > 0 {
				boonCount++
				insertFeatFeatures(tx, "boon_features", "boon_id", id, card.Contents)
			}
		} else {
			res, err := tx.Exec(
				`INSERT OR IGNORE INTO feats (name, prerequisite, description, source) VALUES (?,?,?,?)`,
				card.Title, prereq, truncate(desc, 2000), source,
			)
			if err != nil {
				log.Printf("SeedFeats: insert feat %q: %v", card.Title, err)
				continue
			}
			id, _ := res.LastInsertId()
			if id > 0 {
				featCount++
				insertFeatFeatures(tx, "feat_features", "feat_id", id, card.Contents)
			}
		}
	}

	if err := tx.Commit(); err != nil {
		log.Printf("SeedFeats: commit feats: %v", err)
		return
	}
	log.Printf("SeedFeats: %d feats, %d boons", featCount, boonCount)
}

func seedFightingStylesAndInvocations() {
	var cards []optionCard
	if err := json.Unmarshal(fightingStylesInvocations, &cards); err != nil {
		log.Printf("SeedFeats: parse fighting styles/invocations: %v", err)
		return
	}

	phb24 := make(map[string]bool)
	for _, c := range cards {
		if hasTag(c.Tags, "PHB'24") {
			phb24[c.Title] = true
		}
	}

	tx, err := DB.Begin()
	if err != nil {
		log.Printf("SeedFeats: begin fighting tx: %v", err)
		return
	}
	defer tx.Rollback()

	styleCount, invocCount := 0, 0

	for _, card := range cards {
		if !hasTag(card.Tags, "PHB'24") && phb24[card.Title] {
			continue
		}

		_, desc := parseFeatContent(card.Contents)
		props := parseContentsProps(card.Contents)
		prereq := props["Prerequisites"]
		if prereq == "—" {
			prereq = ""
		}

		if fightingStyleNames[card.Title] {
			availableTo := fightingStyleAvailability(card.Title)
			if _, err := tx.Exec(
				`INSERT OR IGNORE INTO fighting_styles (name, description, available_to) VALUES (?,?,?)`,
				card.Title, truncate(desc, 1500), availableTo,
			); err == nil {
				styleCount++
			}
		} else {
			prereqLevel := parsePrereqLevel(prereq)
			prereqSpell := ""
			if strings.Contains(prereq, "Pact of") {
				prereqSpell = prereq
			}
			if _, err := tx.Exec(
				`INSERT OR IGNORE INTO eldritch_invocations (name, prerequisite_level, prerequisite_spell, description) VALUES (?,?,?,?)`,
				card.Title, prereqLevel, prereqSpell, truncate(desc, 1500),
			); err == nil {
				invocCount++
			}
		}
	}

	if err := tx.Commit(); err != nil {
		log.Printf("SeedFeats: commit fighting: %v", err)
		return
	}
	log.Printf("SeedFeats: %d fighting styles, %d invocations/maneuvers", styleCount, invocCount)
}

// parseFeatContent extracts the prerequisite string and full description text
// from a feat/boon/invocation card's contents array.
func parseFeatContent(contents []string) (prereq, desc string) {
	var descParts []string
	for _, line := range contents {
		parts := splitContent(line)
		if len(parts) == 0 {
			continue
		}
		switch parts[0] {
		case "property":
			if len(parts) == 3 && (strings.Contains(parts[1], "Prerequisites") || strings.Contains(parts[1], "Type")) {
				prereq = cleanText(parts[2])
				if prereq == "—" {
					prereq = ""
				}
			}
		case "description":
			if len(parts) == 3 {
				descParts = append(descParts, cleanText(parts[1])+": "+cleanText(parts[2]))
			}
		case "text", "bullet":
			val := cleanText(parts[len(parts)-1])
			if val != "" {
				descParts = append(descParts, val)
			}
		}
	}
	desc = strings.Join(descParts, " ")
	return
}

// insertFeatFeatures inserts description lines as feature rows.
func insertFeatFeatures(tx *sql.Tx, table, idCol string, parentID int64, contents []string) {
	for _, line := range contents {
		parts := splitContent(line)
		if len(parts) == 3 && parts[0] == "description" {
			name := cleanText(parts[1])
			desc := cleanText(parts[2])
			if name != "" && desc != "" {
				tx.Exec(
					fmt.Sprintf(`INSERT OR IGNORE INTO %s (%s, name, description) VALUES (?,?,?)`, table, idCol),
					parentID, name, desc,
				)
			}
		}
	}
}

// fightingStyleAvailability returns a comma-separated list of classes that
// have access to each fighting style based on their class feature lists.
func fightingStyleAvailability(name string) string {
	switch name {
	case "Blessed Warrior":
		return "Paladin"
	case "Druidic Warrior":
		return "Ranger"
	case "Archery", "Defense", "Dueling", "Great Weapon Fighting",
		"Interception", "Protection", "Two-Weapon Fighting":
		return "Fighter, Paladin, Ranger"
	default:
		return "Fighter, Paladin, Ranger"
	}
}

// parsePrereqLevel extracts a minimum level from a prerequisite string.
// "Lvl 5, Pact of the Blade" → 5
func parsePrereqLevel(prereq string) int {
	lower := strings.ToLower(prereq)
	idx := strings.Index(lower, "lvl")
	if idx == -1 {
		return 0
	}
	rest := strings.TrimSpace(prereq[idx+3:])
	fields := strings.Fields(rest)
	if len(fields) == 0 {
		return 0
	}
	n, _ := strconv.Atoi(strings.TrimRight(fields[0], ",;"))
	return n
}
